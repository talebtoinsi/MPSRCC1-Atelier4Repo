ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY 'Wissem123!';
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Wissem123!';
FLUSH PRIVILEGES;





